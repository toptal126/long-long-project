---
title: Engine
slug: Glossary/Engine
tags:
  - CodingScripting
  - NeedsContent
---

The {{glossary("JavaScript")}} engine is an interpreter that parses and executes a JavaScript program.

## See also

- [JavaScript engine](https://en.wikipedia.org/wiki/JavaScript_engine) on Wikipedia
