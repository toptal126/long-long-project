---
title: buffer
slug: Glossary/buffer
tags:
  - Buffer
  - CodingScripting
  - NeedsContent
---

A buffer is a storage in physical memory used to temporarily store data while it is being transferred from one place to another.

## See also

- [Data buffer](https://en.wikipedia.org/wiki/Data_buffer) on Wikipedia
