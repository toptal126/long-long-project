---
title: privileged code
slug: Glossary/privileged_code
tags:
  - privileged
---

**Privileged code** - JavaScript code of your extension. For example, code in content scripts.

**Non-privileged** - JavaScript on web-page.
