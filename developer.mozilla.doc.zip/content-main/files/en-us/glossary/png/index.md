---
title: PNG
slug: Glossary/PNG
tags:
  - Beginner
  - Composing
  - Infrastructure
  - PNG
---

**PNG** (Portable Network Graphics) is a graphics file format that supports lossless data compression.

## See also

- [PNG](https://en.wikipedia.org/wiki/Portable_Network_Graphics) on Wikipedia
