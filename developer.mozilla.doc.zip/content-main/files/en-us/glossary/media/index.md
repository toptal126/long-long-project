---
title: Media
slug: Glossary/Media
tags:
  - Disambiguation
---

The term **media** is an overloaded one when talking about the web; it takes on different meanings depending on the context.

{{GlossaryDisambiguation}}

## See also

- [Media](https://en.wikipedia.org/wiki/Media) on Wikipedia
