---
title: Denial of Service
slug: Glossary/Denial_of_Service
tags:
  - Attack
  - Denial of Service
  - Intro
  - Security
---

DoS (Denial of Service) is a category of network attack that consumes available server resources, typically by flooding the server with requests. The server is then sluggish or unavailable for legitimate users.

See [DoS attack](/en-US/docs/Glossary/DOS_attack) for more information.
