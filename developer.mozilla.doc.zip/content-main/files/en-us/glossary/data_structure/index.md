---
title: Data structure
slug: Glossary/Data_structure
tags:
  - CodingScripting
  - Data structure
---

**Data structure** is a particular way of organizing _data_ so that it can be used efficiently.

## See also

- [Data structure](https://en.wikipedia.org/wiki/Data_structure) on Wikipedia
