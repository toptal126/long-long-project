---
title: Block
slug: Glossary/Block
tags:
  - Disambiguation
---

The term **block** can have several meanings depending on the context. It may refer to:

{{GlossaryDisambiguation}}
