---
title: Property
slug: Glossary/property
tags:
  - Disambiguation
---

The term **property** can have several meanings depending on the context. It may refer to:

{{GlossaryDisambiguation}}
