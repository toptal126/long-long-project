---
title: ISO
slug: Glossary/ISO
tags:
  - ISO
  - Infrastructure
  - Web Standards
  - web specifications
---

**ISO** (International Organization for Standardization) is a global association that develops uniform criteria coordinating the companies in each major industry.

## See also

- [Official website](https://www.iso.org/home.html)
