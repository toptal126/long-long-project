---
title: GPU
slug: Glossary/GPU
tags:
  - Graphics
  - Infrastructure
---

The GPU (Graphics Processing Unit) is a computer component similar to the CPU (Central Processing Unit). It specializes in the drawing of graphics (both 2D and 3D) on your monitor.
