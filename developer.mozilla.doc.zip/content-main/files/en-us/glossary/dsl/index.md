---
title: DSL
slug: Glossary/DSL
tags:
  - Disambiguation
---

The term **DSL** can have several meanings depending on the context. It may refer to:

{{GlossaryDisambiguation}}

## See also

- [DSL](<https://en.wikipedia.org/wiki/DSL_(disambiguation)>) on Wikipedia
